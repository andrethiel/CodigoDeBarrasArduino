#ifndef FATFS_UNICODE_H_
#include "../ff.h"

#if _USE_LFN != 0
#include "cc932.h"
#include "cc936.h"
#include "cc949.h"
#include "cc950.h"
#include "ccsbcs.h"
#endif
#endif
